#!/bin/sh
ssh yxu66@stargate.cs.usfca.edu -L 3307:sql.cs.usfca.edu:3306 -N
