
public class matElem implements MatrixElem {
	
	public innerIterator ii;
	public int rowIndex;
	public int colIndex;
	public Object value;
	
	public matElem(LinkedList list) {
		while (ii.iteratingCol()) {
			rowIndex = list.size();
			value = list.get(rowIndex);
		}
		while (ii.iteratingCol()) {
			colIndex = list.size();
			value = list.get(colIndex);
		}
	
		
	}
	
	@Override
	public int rowIndex() {
		
		return rowIndex;
	}

	@Override
	public int columnIndex() {
		
		return colIndex;
	}

	@Override
	public Object value() { 
		
		return value;
	}

}
