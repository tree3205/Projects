

public class MySparseArray implements SparseArray {

	public Object defaultValue;
	public Object value;
	public rowElem ri;
	public colElem ci;
	
	MySparseArray(Object[][] matrix, Object defaultValue) {
		this.defaultValue = defaultValue;
	}
	
	@Override
	public Object defaultValue() {
		return defaultValue;
	}

	@Override
	public RowIterator iterateRows() {
		
		return ri;
	}

	@Override
	public ColumnIterator iterateColumns() {
		return ci;
	}

	@Override
	public Object elementAt(int row, int col) {
		return null;
	}

	@Override
	public void setValue(int row, int col, Object value) {
		
	}
		
}

