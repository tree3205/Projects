public class test {
	public static void main(String[] args) {
		Object [][] matrix =  { {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
								{0, 3, 5, 0, 0, 0, 0, 9, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 5, 0, 0},
								{0, 0, 0, 0, 0, 5, 0, 0, 0, 22}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
								{0, 0, 0, 0, 0, 5, 0, 0, 0, 0}, {0, 0, 5, 0, 0, 0, 0, 0, 5, 0},
								{0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 5}};
		
		MySparseArray a = new MySparseArray(matrix, 0);
		LinkedList rowlist = new LinkedList();
		LinkedList elemlist = new LinkedList();
		
		for (int i = 0; i < matrix.length; i++) {
			rowlist.add(matrix[i]);
			for (int j = 0; j < matrix[i].length; j++) {
				elemlist.add(matrix[i][j]);
			}
		}
		System.out.println(rowlist);
		System.out.println(elemlist);
	}
}