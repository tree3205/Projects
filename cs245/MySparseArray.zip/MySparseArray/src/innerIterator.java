import java.util.NoSuchElementException;

public class innerIterator extends ElemIterator {

	public rowElem ri;
	public colElem ci;
	public innerIterator ei;
	public matElem m;
	public LinkedList list;
	public int offset;
	private static final innerIterator emptyElemIterator = new innerIterator(new LinkedList());
	
	public innerIterator(LinkedList list) 
	{
		this.list = list;
		offset = -1;
		advance();
	}
	
	private boolean advance() {
		while (++offset < list.size()) {
            if (list.get(offset) != null) {
                return true;
            }
        }
        return false;
	}

	@Override
	public boolean iteratingRow() {
		if (ci.hasNext() && ci.next() != null) {
			return true;
		}
		return false;
	}

	@Override
	public boolean iteratingCol() {
		if (ri.hasNext() && ri.next() != null) {
			return true;
		}
		return false;
	}

	@Override
	public int nonIteratingIndex() {
		if (ei.iteratingCol() == true) {
			return m.rowIndex();
		}
		if (ei.iteratingRow() == true) {
			return m.columnIndex();
		}	
		return -1;
	}

	@Override
	public MatrixElem next() {
		if (offset < list.size()) {
			advance();
			return m;
		}
		else {
            throw new NoSuchElementException();
		}
	}

	@Override
	public boolean hasNext() {
		return offset < list.size();
	}
	
	public void remove() {
	       throw new UnsupportedOperationException();
	}
	
	public static ElemIterator buildIterator(LinkedList list) {
		if (list == null || list.size() == 0) {
			return emptyElemIterator;
        } else {
            return new innerIterator(list);
        }
	}
}
	


