
public interface MatrixElem 
{	
   public abstract int rowIndex();
   public abstract int columnIndex();
   public abstract Object value();

}
