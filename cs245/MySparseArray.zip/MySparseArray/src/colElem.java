import java.util.NoSuchElementException;


public class colElem extends ColumnIterator{
	
	public static final colElem emptyColIterator = new colElem(new Object[0]);
	
	public innerIterator ii;
	private Object[] myList;
	private int offset;
	
	public colElem(Object[] LinkedList) {
		myList = LinkedList;
		offset = -1;
		advance();
	}
	
	private boolean advance() {
		while (++offset < myList.length) {
            if (myList[offset] != null) {
                return true;
            }
        }
        return false;
	}

	@Override
	public ElemIterator next() {
		if (offset < myList.length) {
			return ii;
        } else {
            throw new NoSuchElementException();
        }
	}

	@Override
	public boolean hasNext() {
		return offset < myList.length;
	}
	
	public void remove() {
	       throw new UnsupportedOperationException();
	}
	
	public static ColumnIterator buildIterator(Object[] LinkedList) {
		if (LinkedList == null || LinkedList.length == 0) {
			return emptyColIterator;
        } else {
            return new colElem(LinkedList);
        }
	}

}
