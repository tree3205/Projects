import java.util.Iterator;
import java.util.LinkedList;


public class SortTest {

	
	
	
	public static void main(String[] args) {
		Comparable[] array1 = new Integer[]{2,3,4,6,13,5,1,7,11,12,9};
		Comparable[] array2 = new Integer[]{3,18,4,20,61,15,1,7,11,12,9,13,28,25,6,53};
		Comparable[] array4 = new Integer[]{3,5,2,7,10,4,9,11,12,8};
 		int[] array3 = new int[]{3,18,4,20,61,15,1,7,-11,12,9,13,28,25,6,53};
		
		LinkedList<LLNode> list = new LinkedList<LLNode>();
		LLNode node0 = new LLNode(2);
		LLNode node1 = new LLNode(3);
		LLNode node2 = new LLNode(4);
		LLNode node3 = new LLNode(6);
		LLNode node4 = new LLNode(13);
		LLNode node5 = new LLNode(5);
		LLNode node6 = new LLNode(1);
		LLNode node7 = new LLNode(7);
		LLNode node8 = new LLNode(11);
		LLNode node9 = new LLNode(12);
		LLNode node10 = new LLNode(9);
		
		list.add(node0);
		list.add(node1);
		list.add(node2);
		list.add(node3);
		list.add(node4);
		list.add(node5);
		list.add(node6);
		list.add(node7);
		list.add(node8);
		list.add(node9);
		list.add(node10);
		//System.out.println(list);
		//System.out.println(list.element().elem());
		//System.out.println(list.element().next());
		
		//sort.insertionSortLL(node0, true);
		//sort.insertionSortLL(node0, false);
		
		Sort sort = new Sort();
		sort.insertionSort(array1, 4, 8, true);
		sort.insertionSort(array1, 4, 8, false);

		sort.selectionSort(array1, 3, 9, true);
		sort.selectionSort(array1, 3, 9, false);

		sort.shellSort(array2, 2, 10, true);
		sort.shellSort(array2, 2, 10, false);

		sort.bucketSort(array3, 2, 10, true);
		sort.bucketSort(array3, 2, 10, false);
		
		sort.heapSort(array2, 2, 10, true);
		sort.heapSort(array4, 2, 7, false);

		
		
		
	}

}
